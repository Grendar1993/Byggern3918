/*
 * ADC.h
 *
 * Created: 20.09.2018 16.44.04
 *  Author: Max-Pc
 */ 


#ifndef ADC_H_
#define ADC_H_

int ADC_init(void);
uint8_t ADC_read(uint8_t channel);


#endif /* ADC_H_ */